import pandas as pd
import numpy as np
import optimize_memory_usage
from optimize_memory_usage import optimize_memory_usage
'''
Input data:
    path_input_file - path input csv file of muutations
    range - separation of mutations by class relattive to ddG
    print_size - flag printing change useg memory
Output data
    DataFrame of single mutations data with columns:
        mutation - the name of the mutation, for example, A12G;
        start_amino - mutating residue;
        end_amino - mutated residue;
        index - position of mutation;
        chain - the name of the chain in which the mutation occurred;
        ddG - the change in the change in Gibbs free energy;
        type_ddG - type of ddG;
        pdb - name of protein in which the mutation occured;
'''


def load(path_input_file, split):
    # Load csv-file and select columns
    df = pd.read_csv(path_input_file, delimiter=";", low_memory=False, error_bad_lines=False)
    # Select data with single mutation and remove data containing NaN in rows
    df = df.dropna()
    df = df[df["mutation_type"] == "single"]
    # Select columns: mutation, chain, ddG, pdb
    df = df[["mutation", "chain", "ddG", "pdb"]]
    # Add column with ddG classification by range
    labels = [x for x in range(1, len(split))]
    df["type_ddG"] = pd.cut(df["ddG"], split, labels=labels)
    # Add information columns about mutation: starting, ending, index amino acid of mutation
    df['start_amino'] = df["mutation"].apply(lambda x: x[0])
    df['end_amino'] = df["mutation"].apply(lambda x: x[-1])
    df['index'] = df["mutation"].apply(lambda x: x[1:-1]).astype(int)
    # Optimaze memory use object data
    df = optimize_memory_usage(df)
    return df
