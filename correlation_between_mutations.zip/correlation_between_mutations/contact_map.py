import os
import sys
import urllib
import numpy as np
import MDAnalysis as mda
from MDAnalysis.analysis import distances
import warnings
'''
Input data:
    pdbcode - pdb name for download
    datadir - directory for downloading file
    downloaderl - site of rcsb.org for download
Output data:
    path for downloading file or None
'''


def download_pdb(pdbcode, datadir, downloadurl="https://files.rcsb.org/download/"):
    """
    Downloads a PDB file from the Internet and saves it in a data directory.
    :param pdbcode: The standard PDB ID e.g. '3ICB' or '3icb'
    :param datadir: The directory where the downloaded file will be saved
    :param downloadurl: The base PDB download URL, cf.
        `https://www.rcsb.org/pages/download/http#structures` for details
    :return: the full path to the downloaded PDB file or None if something went wrong
    """
    pdbfn = ''.join(("".join(str(x) for x in pdbcode), ".pdb"))
    url = ''.join((downloadurl, pdbfn))
    outfnm = os.path.join(datadir, pdbfn)
    try:
        urllib.request.urlretrieve(url, outfnm)
        return outfnm
    except Exception as err:
        print(str(err), file=sys.stderr)
        return None


# suppress some MDAnalysis warnings when writing PDB files
warnings.filterwarnings('ignore')
'''
Input data:
      pdbs - array of protein names
Output data:
      the dictionary contains the re-indexed residues of proteins from pdb_ids
'''


def creat_reindexing_residues(pdbs):
    reindexing_residues_pdbs = {}
    for pdb_id in pdbs:
        # downloaded file from PDB
        name = ''.join(('./pdbs/', pdb_id, '.pdb'))
        fin = open(name, 'r')
        content = fin.readlines()
        fin.close()
        res = {}
        mis_res = {}
        chains = {}
        flag = False
        # find size chains of protein
        for i, line in enumerate(content):
            if line[0:6] == 'SEQRES':
                chains[line[11:12]] = int(line[12:17])
        # find indices of missing and other residues
        for i, line in enumerate(content):
            # indices of other residues
            if line[0:4] == 'ATOM' and line[21] in chains.keys():
                split = [line[:6], line[6:11], line[12:16], line[19], line[21], line[22:26]]
                # split[4] - name chain, split[5] - index of residues
                if split[2].strip() == "CA" and split[4] in res.keys():
                    if split[5][-1].isdigit():
                        res[split[4]] = np.append(res[split[4]], split[5] + '@')
                    else:
                        res[split[4]] = np.append(res[split[4]], split[5] + '@')
                elif split[2].strip() == "CA":
                    if split[5][-1].isdigit():
                        res[split[4]] = np.array(split[5] + '@')
                    else:
                        res[split[4]] = np.array(split[5])
            # line before missing residues
            if "RES C SSSEQI" in line:
                flag = True
                continue
            # indices of missing residues
            if line[0:10] == 'REMARK 465' and flag and line[19] in chains.keys():
                split = [line[:10], line[19], line[22:26]]
                # split[1] - name chain, split[2] - index of residues
                if split[1] in mis_res.keys():
                    if split[2][-1].isdigit():
                        mis_res[split[1]] = np.append(mis_res[split[1]], split[2] + '@')
                    else:
                        mis_res[split[1]] = np.append(mis_res[split[1]], split[2])
                else:
                    if split[2][-1].isdigit():
                        mis_res[split[1]] = np.array(split[2] + '@')
                    else:
                        mis_res[split[1]] = np.array(split[2])
        numeric = {}
        last = 0
        for chain in chains:
            if chain in mis_res:
                chains[chain] -= len(mis_res[chain])
            now = chains[chain]
            numeric[chain] = last
            last += now
        # join and sort residues in one dictionary
        all_res = {}
        for chain in chains:
            if chain in mis_res:
                all_res[chain] = np.sort(np.append(mis_res[chain], res[chain]))
            else:
                all_res[chain] = res[chain]
        # creat dictionary for reinexed residues("-1" - missing residues)
        reindexing = {}
        for chain in chains:
            reindexing_chain = np.array([], dtype=np.int8)
            index = 1
            for resseq in all_res[chain]:
                if resseq in res[chain]:
                    reindexing_chain = np.append(reindexing_chain, index + numeric[chain])
                    index += 1
                else:
                    reindexing_chain = np.append(reindexing_chain, -1)
            reindexing[chain] = reindexing_chain
        reindexing_residues_pdbs[pdb_id] = reindexing
    
    return reindexing_residues_pdbs


'''
Input data:
      pdbs - array of protein names
      mode - how to calculate the distance between the remnants:
          'CA' - contact between CA
          'center' = contact between center of gravity
      pdb_load = pdb load flag
Output data:
      the dictionary contains contact maps of proteins from pdb_ids
'''


def creat_distant_map(pdbs, mode, pdb_load):
    distant_map = {}
    for pdb_id in pdbs:
        if pdb_load:
            # load PDB file format
            u = mda.Universe(download_pdb(pdb_id, './pdbs/'))
        else:
            u = mda.Universe(''.join(('./pdbs/', pdb_id, '.pdb')), topology_format="PDB")
        if mode == 'ca':
            # select CA atoms
            ca = u.select_atoms('name CA')
            # size contact map(modelled residue count)
            n_ca = len(ca)
            self_distances = distances.self_distance_array(ca.positions)
            sq_dist_arr = np.zeros((n_ca, n_ca))
            triu = np.triu_indices_from(sq_dist_arr, k=1)
            sq_dist_arr[triu] = self_distances
            sq_dist_arr.T[triu] = self_distances
            # save contact map in dictionary
            distant_map[pdb_id] = sq_dist_arr

        if mode == 'center':
            # center of mass of residues
            res_com = u.atoms.center_of_mass(compound='residues')
            # size contact map(modelled residue count)
            n_res = len(res_com)
            sq_dist_res = np.zeros((n_res, n_res))
            triu = np.triu_indices_from(sq_dist_res, k=1)
            res_dist = distances.self_distance_array(res_com)
            sq_dist_res[triu] = res_dist
            sq_dist_res.T[triu] = res_dist
            # save contact map in dictionary
            distant_map[pdb_id] = sq_dist_res
    return distant_map


'''
Input data:
      pdb_ids - array of protein names
      mode - how to calculate the distance between the remnants:
          'CA' - contact between CA
          'center' = contact between center of gravity
      pdb_load = pdb load flag
Output data:
      two dictionaries:
          the first dictionary contains contact maps of proteins from pdb_ids
          the second dictionary contains the re-indexed residues of proteins from pdb_ids
'''


def creat_distant_map_and_reindexed_residues(pdbs, mode, pdb_load):
    return creat_distant_map(pdbs, mode, pdb_load), creat_reindexing_residues(pdbs)
