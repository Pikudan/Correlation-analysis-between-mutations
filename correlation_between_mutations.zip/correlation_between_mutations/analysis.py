'''
Input Data:
    DataFrame containing columns:
        ddG, ddGXX, where XX - mutation-predictor
        type_ddG, type_ddGXX, where XX - mutation-predictor
    predictor, response - names two mutations
    array - array for adding Pearson, Spearman correlations, p-value and Chi squared test
Output Data:
    array - array with added Pearson, Spearman correlations, p-value and Chi squared test
'''
import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency
from scipy.stats import spearmanr
from scipy.stats import pearsonr


# Pearson, Spearman correlations and their p-value between ddG of predictor and response mutation
def corr(sample, predictor, response):
    s, sp_value = spearmanr(sample[''.join(('ddG', predictor))], sample[''.join(('ddG', response))])
    p, pp_value = pearsonr(sample[''.join(('ddG', predictor))], sample[''.join(('ddG', response))])
    return [s, sp_value, p, pp_value]


# Chi squared test for type ddG of predictor and response mutation
def chi2(sample, predictor, response):
    vote_table = pd.crosstab(sample[''.join(('type_ddG', predictor))], sample[''.join(('type_ddG', response))])
    return chi2_contingency(vote_table)[0:3]


'''
Input data
    DataFrame of couple mutations response and predictor
    array - array of analys correlation between mutations
'''


def analys(df, predictor, response, array, print_size):
    if print_size:
        print("Size table contains {1} mutations by {0} mutations: {2}".format(predictor, response, len(df)))
    if len(df) > 8:
        array = np.append(array, [predictor, response, len(df)])
        array = np.append(array, corr(df, predictor, response))
        array = np.append(array, chi2(df, predictor, response))
    else:
        array = np.append(array, [predictor, response, len(df), 0, 0, 0, 0, 0, 0, 0])
    return array
