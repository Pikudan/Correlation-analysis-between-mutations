'''
Creat a DataFrame of mutation-predictor and mutation-response
pairs that are adjacent in a structure or sequence.
Input data:
    Two DataFrame with mutation-predictor and mutation-response;
    pred, resp - names two mutations;
    mode - "structure/sequence":
        "structure" uses a contact map to find close pairs.
        "sequence" uses a index mutation to find close pairs.
    contact_map - contact map is required when mode="structure";
    env - environment of inclusion in a pair of muations;
Output data:
    DataFrame of mutation-predictor and mutation-response pairs
'''
import pandas as pd


def creat_merge(df_pred, df_resp, pred, resp, mode, distant_map, radius, env):
    result = pd.merge(df_pred, df_resp, on=["pdb"], how="left")
    # drop NaN
    result = result.dropna()
    # This strange result merge: converting type from int to float ._.
    result[''.join(("index", pred))] = result[''.join(("index", pred))].astype('int')
    result[''.join(("index", resp))] = result[''.join(("index", resp))].astype('int')
    if len(result) != 0:
        if mode == "structure":
            contact = result.apply(
                lambda x: abs(distant_map[x["pdb"]][x[''.join(("index", resp))] - 1, x[''.join(("index", pred))] - 1]) < radius
                and abs(distant_map[x["pdb"]][x[''.join(("index", resp))] - 1, x[''.join(("index", pred))] - 1]) > 0,
                axis=1)
        else:
            contact = result.apply(
                lambda x: x[''.join(("chain", pred))] == x[''.join(("chain", resp))]
                and x[''.join(("index", resp))] - x[''.join(("index", pred))] in env,
                axis=1)
        result = result[contact]
    return result


'''
Input Data:
    DataFrame containing columns:
            "pdb", "ddG", "type_ddG", "mutation", "index", "start_amino", "end_amino"
    mutations - mutation names
Output Data:
    Dictionary with DataFrames about mutations. DataFrames containing columns:
            "pdb", "ddGXY", "indexXY", "type_ddGXY", where XY - name mutation
'''
def creat_mutations_tables(df, mutations):
    mutations_tables = dict()
    for mutation in mutations:
        table = df[((df['start_amino'] == mutation[0]) & (df['end_amino'] == mutation[1]))].copy()
        table = table[["pdb", "chain", "ddG", "index", "type_ddG"]]
        table.columns = [
        "pdb",
        ''.join(("chain", mutation)),
        ''.join(("ddG", mutation)),
        ''.join(("index", mutation)),
        ''.join(("type_ddG", mutation))
        ]
        mutations_tables[mutation] = table
    return mutations_tables
        
