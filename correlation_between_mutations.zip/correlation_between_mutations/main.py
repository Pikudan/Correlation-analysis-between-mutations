'''
Input data:
    From script.sh:
        path_input_file - path input csv file of muutations
        path_ouput_file - path creat csv file of analys:
            Spearmman and Pearson correlations and their  p-values,
            Chi squared test;
    Can be entered by the user further:
        range - separation of mutations by class relative to ddG;
        environment - environment of inclusion in a pair of muations(predictor and any other);
        c - count pair mutations for analysis;
        load_pdb - flag load pdb;
        predictor, response - names two mutations. Can you use only predictor or both together
        or nothing(then the program will simpply sort throuugh all possible pairs;
        mode_contact_map - how calculate distance between residius:
            'ca' - contact between CA
            'center' = contact between center of mass
        mode - "structure/sequence":
            "structure" uses a contact map to find close pairs.
            "sequence" uses a index mutation to find close pairs.
        radius - maximum distance between a pair of mutations(predictor and any other) in space(Angstrem)
        print_size - flag printing change useg memory;
    Default:
            range = [-10, 0.5, 0.5, 10]
            environment = [-1, 0, 1]
            c = 400;
            load_pdb = False;
            predictor, response = ALL;
            mode = 'structure';
            mode_distant_map = 'ca';
            radius = 6;
            print_size = False;
'''

import sys
from load import load
import numpy as np
import pandas as pd
import itertools as it
from analysis import analys
import preparing_data_for_analysis
from preparing_data_for_analysis import creat_mutations_tables
from preparing_data_for_analysis import creat_merge
import optimize_memory_usage
import contact_map
from contact_map import creat_distant_map_and_reindexed_residues


def main(path_input_file=None, path_output_file=None):
    range = [-10, -0.5, 0.5, 10]
    environment = [-1, 0, 1]
    c = 400
    load_pdb = False
    predictor = "ALL"
    response = "ALL"
    mode = "structure"
    mode_distant_map = 'ca'
    radius = 6
    print_size = True
    print('''Chosen parameters:\n
        \trange = {0}\n
        \tenvironment = {1}\n
        \tc = {2}\n
        \tload_pdb = {3}\n
        \tpredictor = {4}\n
        \tresponse = {5}\n
        \tmode = {6}\n
        \tmode_distant_map = {7}\n
        \tradius = {8}\n
        \tprint_size = {9}\n
        '''.format(
            range,
            environment,
            c,
            load_pdb,
            predictor,
            response,
            mode,
            mode_distant_map,
            radius,
            print_size)
    )
    amino_acids = np.array([
    "A", "R", "N", "D", "C", "E", "Q", "G", "H", "I",
    "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V"])
    mutations = ["".join((x, y)) for x, y in it.permutations(amino_acids, 2)]
    change = input("\tDo you want change default parameters?: (y/n)\n\t\t").lower().strip()
    if change == "y":
        range = [float(x) for x in input('''
        Change range: x1 x2 ..., where x1 < x2 < ...\n\t\t''').split()]
        c = int(input("\tChange c - count pair mutations for analys\n\t\t"))
        while c <= 0:
            c = int(input("\tInvalid parameter. c is positive value. Re-enter count pair\n\t\t"))
        
        load_pdb = input("\tChange load_pdb: False/True\n\t\t").lower()
        while load_pdb != "true" and load_pdb != "false":
            load_pdb = input("\tInvalid parameter. load_pdb is bool-value. Re-enter value\n\t\t").lower()
        if load_pdb == "true":
            load_pdb = True
        elif load_pdb == "false":
            load_pdb = False
            
        predictor, response = input('''
        Change name predictor and response mutation as AR CN or AR ALL or ALL ALL\n\t\t''').upper().split()
        while predictor not in mutations and predictor != "ALL":
            predictor= input("Invalid predictor. Change name as AR, AN, ... or ALL\n''').upper()")
        while response not in mutations and response != "ALL":
            response = input("Invalid response. Change name as AR, AN, ... or ALL\n''').upper()")
        mode = input('''
        Change mode 'structure' or 'sequence':
        \n\t'structure' uses a contact map to find close pairs
        \n\t'sequence' uses a index mutation to find close pairs
        \n\t\t''').lower()
        while mode != "structure" and mode != "sequence":
            mode = input('''
            Invalid parameter. mode can only be defined structure or sequence.
            Re-enter mode\n\t\t''').lower()
        if mode == "structure":
            environment = None
            mode_distant_map = input('''
            Change mode_contact_map - how calculate distance between residius:
            \n\t'ca' - contact between CA
            \n\t'center' - contact between center of mass
            \n\t\t''').lower()
            while mode_distant_map != "ca" and mode_distant_map != "center":
                mode_distant_map = input('''
                Invalid parameter. mode_distant_map can only be defined ca or center.
                Re-enter mode_contact_map\n\t\t''').lower()
            radius = int(input('''
            Maximum distance between mutations(predictor and any other in Angstrem).\n\t\t'''))
            while radius < 0:
                radius = int(input('''
                Invalid parameter. Radius is positive value. Re-enter radius.\n\t\t'''))
        else:
            mode_distant_map = None
            environment = [int(i) for i in input('''
            Change environment - environment of pair of muations, for example -1 0 1\n''').split()]
            radius = None
        print_size = input('''
        Print size tables of couple mutations: False/True.\n\t\t''').lower()
        while print_size != "true" and print_size != "false":
            print_size = input('''
            Invalid parameters. print_size is bool-value. Re-enter print_size.\n\t\t''').lower()
        if load_pdb == "true":
            load_pdb = True
        elif load_pdb == "false":
            load_pdb = False
        print('''Chosen parameters:\n
        \trange = {0}\n
        \tenvironment = {1}\n
        \tc = {2}\n
        \tload_pdb = {3}\n
        \tpredictor = {4}\n
        \tresponse = {5}\n
        \tmode = {6}\n
        \tmode_distant_map = {7}\n
        \tradius = {8}\n
        \tprint_size = {9}\n
        '''.format(
            range,
            environment,
            c,
            load_pdb,
            predictor,
            response,
            mode,
            mode_distant_map,
            radius,
            print_size)
        )
    df = load(path_input_file, range)
    if mode == "structure":
        #creat contact map and reindexed residues
        distant_map, reindexed = creat_distant_map_and_reindexed_residues(
            df["pdb"].unique(),
            mode_distant_map,
            load_pdb)
        # reindexed residues
        df["index_original"] = df["index"]
        df["index"] = df.apply(lambda x: reindexed[x["pdb"]][x["chain"]][x["index"] - 1], axis=1)
        # delete unmodelled residues
        df = df[df["index"] != -1]
        big_pdbs = [pdb for pdb in distant_map if len(distant_map[pdb]) > 100]
        for pdb in big_pdbs:
            del distant_map[pdb]
        small_pdbs = df.apply(lambda x: x["pdb"] not in big_pdbs,  axis=1)
        df = df[small_pdbs]
    else:
        distant_map = {}
    # array of possible mutations

    result = np.array([])
    responses = mutations.copy()
    tables_mutation = creat_mutations_tables(df, mutations)
    if predictor != "ALL":
        if response != "ALL":
            # creat Dataframe of a pair of mutations(predictor and response)
            merge = creat_merge(
                tables_mutation[predictor],
                tables_mutation[response],
                predictor,
                response,
                mode,
                distant_map,
                rasius,
                environment
            )
            # correlation analysis of a pair of mutations (predictor and response)
            result = analys(merge, predictor, response, result, print_size)
        else:
            for response in mutations:
                if c == 0:
                    break
                if predictor == response:
                    continue
                # creat Dataframe of a pair of mutations(predictor and response)
                merge = creat_merge(
                    tables_mutation[predictor],
                    tables_mutation[response],
                    predictor,
                    response,
                    mode,
                    distant_map,
                    radius,
                    environment
                )
                # correlation analysis of a pair of mutations (predictor and response)
                result = analys(merge, predictor, response, result, print_size)
                c -= 1
    else:
        for predictor in mutations:
            if c == 0:
                break
            responses.remove(predictor)
            for response in responses:
                if c == 0:
                    break
                # creat Dataframe of a pair of mutations(predictor and response)
                merge = creat_merge(
                    tables_mutation[predictor],
                    tables_mutation[response],
                    predictor,
                    response,
                    mode,
                    distant_map,
                    radius,
                    environment
                )
                # correlation analysis of a pair of mutations (predictor and response)
                result = analys(merge, predictor, response, result, print_size)
                c -= 1
    # creat DataFrame with analys
    result_pd = pd.DataFrame({"predictor": result[0::10],
    "response": result[1::10], "len": result[2::10].astype(int),
    "spearman": result[3::10].astype(float), "p-value-spearman": result[4::10].astype(float),
    "pearson": result[5::10].astype(float), "p-value-pearson": result[6::10].astype(float),
    "F-statistic": result[7::10].astype(float), "p-value-chi2": result[8::10].astype(float),
    "The-degrees-of-freedom": result[9::10].astype(float)})
    # write result to csv to path_output_file
    result_pd.to_csv(path_output_file, index=False)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Error. Not enough parameters.")
        sys.exit(1)
    if len(sys.argv) > 3:
        print("Error. Too many parameters.")
        sys.exit(1)
    path_input_file = sys.argv[1]
    path_output_file = sys.argv[2]
    main(path_input_file, path_output_file)
